package ir.forestmeasure.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.util.Locale;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final String[] species = {"بلوط","بادام","ارس","گیلاس وحشی","دافنه","افرا","پسته وحشی","سایر"};
    private EditText treeNo, plotNo, circumference, height, formFactor, classWidth, latitude, longitude, crown, notes;
    private Spinner speciesSpinner;
    private TextView result, summary;
    private LinearLayout rows;
    private DB db;
    private LocationManager locationManager;
    private double currentLat = Double.NaN, currentLon = Double.NaN;
    private int treeCount = 0;
    private static final int REQ_LOCATION = 10;
    private static final int CREATE_CSV = 11;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        db = new DB();
        buildUI();
        updateSummary();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView label(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(0xff183d2b);
        t.setTextSize(14); t.setGravity(Gravity.RIGHT); t.setPadding(dp(2),dp(5),dp(2),dp(2)); return t;
    }
    private EditText edit(String hint, boolean numeric) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint);
        e.setTextSize(14); e.setGravity(Gravity.RIGHT);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        return e;
    }
    private Button button(String text, Runnable run) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setOnClickListener(v -> run.run()); return b;
    }
    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14),dp(12),dp(14),dp(18)); page.setBackgroundColor(0xffeef5ed);
        scroll.addView(page);
        TextView title = new TextView(this); title.setText("🌳 اندازه‌گیری درختان جنگلی");
        title.setTextColor(-1); title.setTextSize(21); title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setPadding(dp(8),dp(18),dp(8),dp(18));
        title.setBackgroundColor(0xff174d35); page.addView(title);
        TextView sub = label("ثبت میدانی • محاسبات جنگل‌سنجی • کارکرد آفلاین");
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,dp(10),0,dp(6)); page.addView(sub);

        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(10),dp(8),dp(10),dp(8)); form.setBackgroundColor(0xffffffff); page.addView(form);
        form.addView(label("شماره درخت")); treeNo = edit("مثلاً 1", true); treeNo.setText("1"); form.addView(treeNo);
        form.addView(label("شماره پلات")); plotNo = edit("مثلاً P1", false); plotNo.setText("1"); form.addView(plotNo);
        form.addView(label("گونه درخت")); speciesSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, species);
        speciesSpinner.setAdapter(adapter); form.addView(speciesSpinner);
        form.addView(label("محیط تنه (سانتی‌متر)")); circumference = edit("محیط در ارتفاع 1.3 متر", true); form.addView(circumference);
        form.addView(label("ارتفاع درخت (متر)")); height = edit("اختیاری؛ برای حجم لازم است", true); form.addView(height);
        form.addView(label("ضریب شکل (پیش‌فرض 0.5)")); formFactor = edit("0.5", true); formFactor.setText("0.5"); form.addView(formFactor);
        form.addView(label("عرض طبقه قطری (سانتی‌متر)")); classWidth = edit("5", true); classWidth.setText("5"); form.addView(classWidth);
        form.addView(label("عرض جغرافیایی (اختیاری)")); latitude = edit("از GPS یا دستی", true); form.addView(latitude);
        form.addView(label("طول جغرافیایی (اختیاری)")); longitude = edit("از GPS یا دستی", true); form.addView(longitude);
        form.addView(label("پوشش تاجی در درصد (اختیاری)")); crown = edit("0 تا 100", true); form.addView(crown);
        form.addView(label("یادداشت میدانی (اختیاری)")); notes = edit("سلامت، وضعیت، توضیحات...", false); form.addView(notes);

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.VERTICAL);
        buttons.addView(button("محاسبه", this::calculate));
        buttons.addView(button("گرفتن مختصات GPS", this::getGPS));
        buttons.addView(button("ثبت درخت", this::saveTree));
        buttons.addView(button("خروجی CSV برای Excel", this::exportCSV));
        buttons.addView(button("پاک کردن فرم", this::clearForm));
        page.addView(buttons);
        result = label("نتیجه محاسبات اینجا نمایش داده می‌شود."); result.setTextSize(15);
        result.setPadding(dp(10),dp(12),dp(10),dp(12)); result.setBackgroundColor(0xffdcebd9); page.addView(result);
        summary = label(""); summary.setTextSize(15); page.addView(summary);
        TextView caveat = label("یادآوری علمی: حجم تقریبی = سطح مقطع × ارتفاع × ضریب شکل. ضریب 0.5 نمونه است؛ برای گزارش رسمی از معادله معتبر گونه/منطقه استفاده کنید. اندازه‌گیری خودکار ارتفاع با دوربین در این نسخه پیاده‌سازی نشده است.");
        caveat.setTextSize(12); caveat.setTextColor(0xff5a4932); caveat.setPadding(dp(8),dp(10),dp(8),dp(10)); page.addView(caveat);
        setContentView(scroll);
    }

    private double num(EditText e, double def) {
        String s = e.getText().toString().trim().replace(',', '.');
        if (s.isEmpty()) return def;
        return Double.parseDouble(s);
    }
    private double[] calc() {
        double c = num(circumference, Double.NaN);
        double h = num(height, Double.NaN);
        double ff = num(formFactor, 0.5);
        double w = num(classWidth, 5);
        if (!Double.isFinite(c) || c <= 0) throw new IllegalArgumentException("محیط تنه را به‌صورت عدد مثبت وارد کنید.");
        if (Double.isFinite(h) && h <= 0) throw new IllegalArgumentException("ارتفاع باید بزرگ‌تر از صفر باشد.");
        if (ff <= 0 || ff > 1) throw new IllegalArgumentException("ضریب شکل باید بیشتر از صفر و حداکثر 1 باشد.");
        if (w <= 0) throw new IllegalArgumentException("عرض طبقه قطری باید بزرگ‌تر از صفر باشد.");
        double dbh = c / Math.PI;
        double ba = Math.PI * Math.pow(dbh / 200.0, 2);
        double vol = Double.isFinite(h) ? ba * h * ff : Double.NaN;
        double low = Math.floor(dbh / w) * w;
        return new double[]{c,h,ff,w,dbh,ba,vol,low,low+w};
    }
    private void calculate() {
        try {
            double[] a = calc();
            String s = String.format(Locale.US, "قطر: %.2f cm\nسطح مقطع: %.4f m²\nطبقه قطری: %.0f تا %.0f cm",
                    a[4], a[5], a[7], a[8]);
            s += Double.isFinite(a[6]) ? String.format(Locale.US, "\nحجم تقریبی: %.4f m³", a[6]) : "\nبرای محاسبه حجم، ارتفاع را وارد کنید.";
            result.setText(s);
        } catch (Exception e) { toast(e.getMessage()); }
    }
    private void saveTree() {
        try {
            if (treeNo.getText().toString().trim().isEmpty() || plotNo.getText().toString().trim().isEmpty())
                throw new IllegalArgumentException("شماره درخت و شماره پلات را وارد کنید.");
            double[] a = calc();
            double cv = num(crown, Double.NaN);
            if (Double.isFinite(cv) && (cv < 0 || cv > 100)) throw new IllegalArgumentException("پوشش تاجی باید بین صفر تا 100 باشد.");
            ContentValues v = new ContentValues();
            v.put("tree_no", treeNo.getText().toString().trim());
            v.put("plot_no", plotNo.getText().toString().trim());
            v.put("species", species[speciesSpinner.getSelectedItemPosition()]);
            v.put("circumference", a[0]); v.put("dbh", a[4]); v.put("height", Double.isFinite(a[1]) ? a[1] : null);
            v.put("basal_area", a[5]); v.put("form_factor", a[2]); v.put("volume", Double.isFinite(a[6]) ? a[6] : null);
            v.put("class_low", a[7]); v.put("class_high", a[8]);
            v.put("latitude", latitude.getText().toString().trim()); v.put("longitude", longitude.getText().toString().trim());
            v.put("crown", Double.isFinite(cv) ? cv : null); v.put("notes", notes.getText().toString().trim());
            v.put("created_at", System.currentTimeMillis());
            db.getWritableDatabase().insert("trees", null, v);
            treeCount++;
            result.setText("درخت شماره " + treeNo.getText().toString() + " ثبت شد.");
            updateSummary();
            try { treeNo.setText(String.valueOf(Integer.parseInt(treeNo.getText().toString()) + 1)); } catch(Exception ignored) {}
        } catch (Exception e) { toast(e.getMessage()); }
    }
    private void updateSummary() {
        Cursor c = db.getReadableDatabase().rawQuery("SELECT COUNT(*), AVG(dbh), AVG(height), SUM(volume) FROM trees", null);
        if (c.moveToFirst()) summary.setText("ثبت‌شده: " + c.getInt(0) +
            " درخت | میانگین قطر: " + (c.isNull(1) ? "—" : String.format(Locale.US,"%.2f cm",c.getDouble(1))) +
            " | میانگین ارتفاع: " + (c.isNull(2) ? "—" : String.format(Locale.US,"%.2f m",c.getDouble(2))) +
            " | مجموع حجم تخمینی: " + (c.isNull(3) ? "—" : String.format(Locale.US,"%.3f m³",c.getDouble(3))));
        c.close();
    }
    private void clearForm() {
        circumference.setText(""); height.setText(""); latitude.setText(""); longitude.setText(""); crown.setText(""); notes.setText("");
        formFactor.setText("0.5"); classWidth.setText("5"); speciesSpinner.setSelection(0);
        result.setText("فرم پاک شد.");
    }
    private void getGPS() {
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); return;
        }
        try {
            Location loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc == null) loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (loc != null) {
                latitude.setText(String.format(Locale.US,"%.6f",loc.getLatitude()));
                longitude.setText(String.format(Locale.US,"%.6f",loc.getLongitude()));
                result.setText("مختصات ثبت شد. اگر دقت بیشتری لازم است، در فضای باز چند لحظه برای دریافت GPS صبر کنید.");
            } else toast("مختصات قبلی موجود نیست؛ GPS را روشن کنید و در فضای باز دوباره امتحان کنید.");
        } catch (SecurityException e) { toast("دسترسی GPS داده نشده است."); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) getGPS();
            else toast("برای ثبت مختصات، اجازه موقعیت مکانی لازم است.");
        }
    }
    private void exportCSV() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "forest_trees.csv");
        startActivityForResult(intent, CREATE_CSV);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_CSV && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 BufferedWriter w = new BufferedWriter(new OutputStreamWriter(out, "UTF-8"))) {
                w.write("\uFEFFشماره درخت,پلات,گونه,محیط سانتی‌متر,قطر سانتی‌متر,ارتفاع متر,سطح مقطع مترمربع,ضریب شکل,حجم مترمکعب,طبقه قطری,عرض جغرافیایی,طول جغرافیایی,پوشش تاجی,یادداشت\n");
                Cursor c = db.getReadableDatabase().rawQuery("SELECT tree_no,plot_no,species,circumference,dbh,height,basal_area,form_factor,volume,class_low,class_high,latitude,longitude,crown,notes FROM trees ORDER BY id", null);
                while (c.moveToNext()) {
                    String[] vals = new String[15];
                    for (int i=0;i<15;i++) vals[i] = c.isNull(i) ? "" : c.getString(i);
                    String line = csv(vals[0])+","+csv(vals[1])+","+csv(vals[2])+","+csv(vals[3])+","+csv(vals[4])+","+csv(vals[5])+","+csv(vals[6])+","+csv(vals[7])+","+csv(vals[8])+","+csv(vals[9]+"-"+vals[10])+","+csv(vals[11])+","+csv(vals[12])+","+csv(vals[13])+","+csv(vals[14]);
                    w.write(line); w.newLine();
                }
                c.close(); w.flush(); toast("فایل خروجی ذخیره شد.");
            } catch (Exception e) { toast("خطا در خروجی: " + e.getMessage()); }
        }
    }
    private String csv(String s) { if (s == null) return "\"\""; return "\"" + s.replace("\"","\"\"") + "\""; }
    private void toast(String s) { Toast.makeText(this, s == null ? "خطای نامشخص" : s, Toast.LENGTH_LONG).show(); }

    private class DB extends SQLiteOpenHelper {
        DB() { super(MainActivity.this, "forest_measure.db", null, 1); }
        public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE trees (id INTEGER PRIMARY KEY AUTOINCREMENT, tree_no TEXT, plot_no TEXT, species TEXT, circumference REAL, dbh REAL, height REAL, basal_area REAL, form_factor REAL, volume REAL, class_low REAL, class_high REAL, latitude TEXT, longitude TEXT, crown REAL, notes TEXT, created_at INTEGER)");
        }
        public void onUpgrade(SQLiteDatabase d, int oldVersion, int newVersion) {}
    }
}
